const STORAGE_KEY = "smelpro_ai_backend_websearch_v3_project_chats_tools";
const OLD_STORAGE_KEYS = [
  "smelpro_ai_backend_websearch_v2_project_chats",
  "smelpro_ai_backend_websearch_v1",
  "smelpro_ai_demo_v1"
];

let selectedDocumentFiles = [];
let autoScrollEnabled = true;
let isGenerating = false;
let currentAbortController = null;
const AUTO_SCROLL_THRESHOLD = 120;


let state = {
  currentProjectId: "general",
  currentChatId: "chat_general",
  expandedProjectId: "general",
  settings: {
    model: "deepseek-v4-flash",
    deepThinking: false,
    useWebSearch: false,
    maxResults: "auto",
    theme: "current",
    sidebarCollapsed: false,
    systemPrompt:
      "Eres un asistente técnico y comercial para Smelpro S.A.C., empresa peruana especializada en IoT industrial, inteligencia artificial, automatización, LoRaWAN, ThingsBoard, medición de agua, energía y tracking. No inventes información si no tienes contexto suficiente. Responde de forma clara, precisa y profesional."
  },
  projects: {
    general: {
      id: "general",
      name: "Proyecto General",
      currentChatId: "chat_general",
      chats: {
        chat_general: {
          id: "chat_general",
          title: "Chat principal",
          messages: [],
          createdAt: Date.now(),
          updatedAt: Date.now()
        }
      }
    }
  }
};

const els = {};

document.addEventListener("DOMContentLoaded", () => {
  cacheElements();
  bindEvents();
  loadState();
});

function cacheElements() {
  els.app = document.querySelector(".app");
  els.toggleSidebarBtn = document.getElementById("toggleSidebarBtn");
  els.model = document.getElementById("model");
  els.themeSelect = document.getElementById("themeSelect");
  els.systemPrompt = document.getElementById("systemPrompt");
  els.deepThinking = document.getElementById("deepThinking");
  els.useWebSearch = document.getElementById("useWebSearch");
  els.maxResults = document.getElementById("maxResults");
  els.saveSettingsBtn = document.getElementById("saveSettingsBtn");
  els.clearChatBtn = document.getElementById("clearChatBtn");
  els.newProject = document.getElementById("newProject");
  els.createProjectBtn = document.getElementById("createProjectBtn");
  els.projectList = document.getElementById("projectList");
  els.newChat = document.getElementById("newChat");
  els.createChatBtn = document.getElementById("createChatBtn");
  els.chatList = document.getElementById("chatList");
  els.composerCard = document.querySelector(".composer-card");
  els.currentProjectTitle = document.getElementById("currentProjectTitle");
  els.currentChatTitle = document.getElementById("currentChatTitle");
  els.status = document.getElementById("status");
  els.chat = document.getElementById("chat");
  els.scrollToBottomBtn = document.getElementById("scrollToBottomBtn");
  els.messageInput = document.getElementById("messageInput");
  els.sendBtn = document.getElementById("sendBtn");
  els.attachBtn = document.getElementById("attachBtn");
  els.documentInput = document.getElementById("documentInput");
  els.attachedFiles = document.getElementById("attachedFiles");
  els.drawerOverlay = document.getElementById("drawerOverlay");
  els.sourcesDrawer = document.getElementById("sourcesDrawer");
  els.sourcesDrawerList = document.getElementById("sourcesDrawerList");
  els.sourcesDrawerSubtitle = document.getElementById("sourcesDrawerSubtitle");
  els.closeSourcesDrawer = document.getElementById("closeSourcesDrawer");
  els.codePreviewOverlay = document.getElementById("codePreviewOverlay");
  els.codePreviewModal = document.getElementById("codePreviewModal");
  els.codePreviewTitle = document.getElementById("codePreviewTitle");
  els.codePreviewFrame = document.getElementById("codePreviewFrame");
  els.closeCodePreview = document.getElementById("closeCodePreview");
}

function bindEvents() {
  els.saveSettingsBtn.addEventListener("click", saveSettings);
  els.clearChatBtn.addEventListener("click", clearCurrentChat);
  els.createProjectBtn.addEventListener("click", createProject);
  if (els.createChatBtn) els.createChatBtn.addEventListener("click", () => createChat());
  els.sendBtn.addEventListener("click", handleSendButtonAction);
  if (els.toggleSidebarBtn) els.toggleSidebarBtn.addEventListener("click", toggleSidebar);
  if (els.chat) els.chat.addEventListener("scroll", handleChatScroll, { passive: true });
  if (els.scrollToBottomBtn) els.scrollToBottomBtn.addEventListener("click", () => {
    autoScrollEnabled = true;
    scrollChatToBottom(true);
  });

  els.deepThinking.addEventListener("change", saveSettings);
  els.useWebSearch.addEventListener("change", saveSettings);
  els.maxResults.addEventListener("change", saveSettings);
  els.model.addEventListener("change", saveSettings);
  if (els.themeSelect) {
    els.themeSelect.addEventListener("change", () => {
      state.settings.theme = els.themeSelect.value;
      applyTheme(state.settings.theme);
      saveSettings();
    });
  }

  els.attachBtn.addEventListener("click", () => els.documentInput.click());
  els.documentInput.addEventListener("change", handleDocumentSelection);
  bindComposerDragAndDrop();
  if (els.closeSourcesDrawer) els.closeSourcesDrawer.addEventListener("click", closeSourcesDrawer);
  if (els.drawerOverlay) els.drawerOverlay.addEventListener("click", closeSourcesDrawer);
  if (els.closeCodePreview) els.closeCodePreview.addEventListener("click", closeCodePreviewModal);
  if (els.codePreviewOverlay) els.codePreviewOverlay.addEventListener("click", closeCodePreviewModal);

  document.addEventListener("click", (event) => {
    if (event.target.closest("#closeCodePreview")) {
      closeCodePreviewModal();
    }
  });
  document.addEventListener("keydown", event => {
    if (event.key === "Escape") {
      closeSourcesDrawer();
      closeCodePreviewModal();
      closeItemActionMenu();
    }
  });

  document.addEventListener("click", event => {
    if (!event.target.closest(".item-action-menu") && !event.target.closest(".item-menu-button")) {
      closeItemActionMenu();
    }
  });

  els.newProject.addEventListener("keydown", event => {
    if (event.key === "Enter") createProject();
  });

  if (els.newChat) {
    els.newChat.addEventListener("keydown", event => {
      if (event.key === "Enter") createChat();
    });
  }

  els.messageInput.addEventListener("keydown", event => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      sendMessage();
    }
  });
}

function handleSendButtonAction() {
  if (isGenerating) {
    stopGeneration();
    return;
  }
  sendMessage();
}

function stopGeneration() {
  if (!currentAbortController) return;
  currentAbortController.abort();
  setStatus("Deteniendo respuesta...");
  setSendButtonMode(false);
}

function setSendButtonMode(generating) {
  isGenerating = generating;
  if (!els.sendBtn) return;
  els.sendBtn.disabled = false;
  els.sendBtn.classList.toggle("stop-mode", generating);
  els.sendBtn.textContent = generating ? "■" : "↑";
  els.sendBtn.title = generating ? "Detener respuesta" : "Enviar";
}

function loadState() {
  const raw = localStorage.getItem(STORAGE_KEY) || getLegacyStateRaw();

  if (raw) {
    try {
      const savedState = JSON.parse(raw);
      state = {
        ...state,
        ...savedState,
        settings: { ...state.settings, ...(savedState.settings || {}) },
        projects: savedState.projects || state.projects
      };
    } catch (error) {
      console.error("No se pudo leer el estado local", error);
    }
  }

  migrateAndValidateState();
  hydrateSettingsForm();
  renderAll();
  setStatus("Listo");
  setSendButtonMode(false);
}

function getLegacyStateRaw() {
  for (const key of OLD_STORAGE_KEYS) {
    const raw = localStorage.getItem(key);
    if (raw) return raw;
  }
  return null;
}

function migrateModelSettings() {
  const modelValue = String(state.settings.model || "deepseek-v4-flash");
  if (modelValue.includes("|")) {
    const [modelName, thinkingType] = modelValue.split("|");
    state.settings.model = modelName || "deepseek-v4-flash";
    state.settings.deepThinking = thinkingType === "enabled";
  }
}

function migrateAndValidateState() {
  if (!state.settings) state.settings = {};
  if (!state.projects) state.projects = {};

  migrateModelSettings();

  if (!state.projects.general) {
    state.projects.general = createProjectObject("general", "Proyecto General");
  }

  Object.values(state.projects).forEach(project => {
    if (!project.id) project.id = "project_" + Date.now();
    if (!project.name) project.name = "Proyecto sin nombre";

    if (!project.chats) {
      const defaultChatId = "chat_" + project.id;
      project.chats = {
        [defaultChatId]: {
          id: defaultChatId,
          title: "Chat principal",
          messages: Array.isArray(project.messages) ? project.messages : [],
          createdAt: Date.now(),
          updatedAt: Date.now()
        }
      };
      project.currentChatId = defaultChatId;
      delete project.messages;
    }

    const chatIds = Object.keys(project.chats);
    if (!chatIds.length) {
      const chat = createChatObject("Chat principal");
      project.chats[chat.id] = chat;
      project.currentChatId = chat.id;
    }

    if (!project.currentChatId || !project.chats[project.currentChatId]) {
      project.currentChatId = Object.keys(project.chats)[0];
    }

    Object.values(project.chats).forEach(chat => {
      if (!Array.isArray(chat.messages)) chat.messages = [];
      if (!chat.title) chat.title = "Chat sin título";
      if (!chat.createdAt) chat.createdAt = Date.now();
      if (!chat.updatedAt) chat.updatedAt = chat.createdAt;
    });
  });

  if (!state.currentProjectId || !state.projects[state.currentProjectId]) {
    state.currentProjectId = "general";
  }

  if (state.expandedProjectId === undefined) {
    state.expandedProjectId = state.currentProjectId;
  }
  if (state.expandedProjectId !== null && !state.projects[state.expandedProjectId]) {
    state.expandedProjectId = state.currentProjectId;
  }

  const project = getCurrentProject();
  state.currentChatId = project.currentChatId;

  if (!state.settings.model) state.settings.model = "deepseek-v4-flash";
  if (state.settings.deepThinking === undefined) state.settings.deepThinking = false;
  if (state.settings.useWebSearch === undefined) state.settings.useWebSearch = false;
  if (!state.settings.systemPrompt) {
    state.settings.systemPrompt =
      "Eres un asistente técnico y comercial para Smelpro. Responde de forma clara, precisa y profesional.";
  }
  if (!state.settings.maxResults) state.settings.maxResults = "auto";
  if (!state.settings.theme) state.settings.theme = "current";
  if (state.settings.sidebarCollapsed === undefined) state.settings.sidebarCollapsed = false;

  saveState();
}

function hydrateSettingsForm() {
  els.model.value = state.settings.model || "deepseek-v4-flash";
  if (els.themeSelect) els.themeSelect.value = state.settings.theme || "current";
  applyTheme(state.settings.theme || "current");
  applySidebarState(Boolean(state.settings.sidebarCollapsed));
  els.systemPrompt.value = state.settings.systemPrompt || "";
  els.deepThinking.checked = Boolean(state.settings.deepThinking);
  els.useWebSearch.checked = Boolean(state.settings.useWebSearch);
  els.maxResults.value = String(state.settings.maxResults || "auto");
  renderAttachedFiles();
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function applyTheme(theme) {
  const allowedThemes = ["current", "dark", "light"];
  const selectedTheme = allowedThemes.includes(theme) ? theme : "current";
  document.body.setAttribute("data-theme", selectedTheme);
}

function applySidebarState(collapsed) {
  if (!els.app) return;
  els.app.classList.toggle("sidebar-collapsed", Boolean(collapsed));
  if (els.toggleSidebarBtn) {
    els.toggleSidebarBtn.textContent = collapsed ? "☰" : "⇤";
    els.toggleSidebarBtn.title = collapsed ? "Mostrar panel lateral" : "Ocultar panel lateral";
  }
}

function toggleSidebar() {
  state.settings.sidebarCollapsed = !Boolean(state.settings.sidebarCollapsed);
  applySidebarState(state.settings.sidebarCollapsed);
  saveState();
}

function saveSettings() {
  state.settings.model = els.model.value;
  state.settings.theme = els.themeSelect ? els.themeSelect.value : (state.settings.theme || "current");
  applyTheme(state.settings.theme);
  state.settings.deepThinking = els.deepThinking.checked;
  state.settings.systemPrompt = els.systemPrompt.value.trim();
  state.settings.useWebSearch = els.useWebSearch.checked;
  state.settings.maxResults = els.maxResults.value || "auto";
  saveState();
  setStatus("Configuración guardada");
}

function createProjectObject(id, name) {
  const chat = createChatObject("Chat principal");
  return {
    id,
    name,
    currentChatId: chat.id,
    chats: {
      [chat.id]: chat
    }
  };
}

function createChatObject(title) {
  const now = Date.now();
  return {
    id: "chat_" + now + "_" + Math.random().toString(16).slice(2),
    title: title || "Nuevo chat",
    messages: [],
    createdAt: now,
    updatedAt: now
  };
}

function createProject() {
  const name = els.newProject.value.trim();

  if (!name) {
    alert("Escribe un nombre para el proyecto.");
    return;
  }

  const id = "project_" + Date.now();
  state.projects[id] = createProjectObject(id, name);
  state.currentProjectId = id;
  state.currentChatId = state.projects[id].currentChatId;
  state.expandedProjectId = id;
  els.newProject.value = "";

  saveState();
  renderAll();
  setStatus("Proyecto creado");
}

function createChat(title = "Nuevo chat", projectId = state.currentProjectId) {
  const project = state.projects[projectId] || getCurrentProject();
  const typedTitle = els.newChat ? els.newChat.value.trim() : "";
  const finalTitle = (typeof title === "string" && title.trim()) ? title.trim() : (typedTitle || "Nuevo chat");
  const chat = createChatObject(finalTitle);

  project.chats[chat.id] = chat;
  project.currentChatId = chat.id;
  state.currentProjectId = project.id;
  state.currentChatId = chat.id;
  state.expandedProjectId = project.id;
  if (els.newChat) els.newChat.value = "";

  saveState();
  renderAll();
  setStatus("Chat creado");
  els.messageInput.focus();
}

function selectProject(id) {
  if (!state.projects[id]) return;

  const wasCurrentProject = state.currentProjectId === id;
  const wasExpanded = state.expandedProjectId === id;

  state.currentProjectId = id;
  const project = getCurrentProject();
  state.currentChatId = project.currentChatId;

  if (wasCurrentProject && wasExpanded) {
    state.expandedProjectId = null;
    setStatus("Proyecto contraído");
  } else {
    state.expandedProjectId = id;
    setStatus(wasCurrentProject ? "Proyecto desplegado" : "Proyecto seleccionado");
  }

  saveState();
  renderAll();
}

function selectChat(id) {
  const project = getCurrentProject();
  if (!project.chats[id]) return;

  project.currentChatId = id;
  state.currentChatId = id;
  state.expandedProjectId = project.id;
  saveState();
  renderAll();
  setStatus("Chat seleccionado");
}

function getCurrentProject() {
  return state.projects[state.currentProjectId] || state.projects.general;
}

function getCurrentChat() {
  const project = getCurrentProject();
  return project.chats[project.currentChatId] || Object.values(project.chats)[0];
}

function renderAll() {
  renderProjects();
  renderConversation();
  renderAttachedFiles();
}

function isChatNearBottom(threshold = AUTO_SCROLL_THRESHOLD) {
  if (!els.chat) return true;
  return els.chat.scrollHeight - els.chat.scrollTop - els.chat.clientHeight <= threshold;
}

function updateScrollToBottomButton() {
  if (!els.scrollToBottomBtn || !els.chat) return;
  const shouldShow = !isChatNearBottom();
  els.scrollToBottomBtn.hidden = !shouldShow;
}

function scrollChatToBottom(force = false) {
  if (!els.chat) return;
  if (force || autoScrollEnabled) {
    els.chat.scrollTop = els.chat.scrollHeight;
  }
  updateScrollToBottomButton();
}

function handleChatScroll() {
  autoScrollEnabled = isChatNearBottom();
  updateScrollToBottomButton();
}

function renderProjects() {
  els.projectList.innerHTML = "";

  Object.values(state.projects).forEach(project => {
    const isExpanded = project.id === state.expandedProjectId;
    const group = document.createElement("div");
    group.className = "project-group" + (isExpanded ? " expanded" : "");

    const header = document.createElement("div");
    header.className = "project-item" + (project.id === state.currentProjectId ? " active" : "");
    header.title = project.name;

    const marker = document.createElement("span");
    marker.className = "project-marker";
    marker.textContent = isExpanded ? "▾" : "▸";

    const title = document.createElement("div");
    title.className = "project-item-title";
    title.textContent = project.name;

    const count = document.createElement("span");
    count.className = "item-count";
    const chatCount = Object.keys(project.chats || {}).length;
    count.textContent = String(chatCount);
    count.title = chatCount + (chatCount === 1 ? " chat" : " chats");

    const menuButton = document.createElement("button");
    menuButton.type = "button";
    menuButton.className = "item-menu-button";
    menuButton.textContent = "⋯";
    menuButton.title = "Opciones del proyecto";
    menuButton.addEventListener("click", event => {
      event.stopPropagation();
      openProjectMenu(event, project.id);
    });

    header.appendChild(marker);
    header.appendChild(title);
    header.appendChild(count);
    header.appendChild(menuButton);
    header.addEventListener("click", () => selectProject(project.id));
    group.appendChild(header);

    if (isExpanded) {
      const nested = document.createElement("div");
      nested.className = "project-chat-tree";

      const newChatButton = document.createElement("button");
      newChatButton.type = "button";
      newChatButton.className = "tree-new-chat-btn";
      newChatButton.innerHTML = "<span>✎</span><span>Nuevo chat</span>";
      newChatButton.title = "Crear nuevo chat en este proyecto";
      newChatButton.addEventListener("click", event => {
        event.stopPropagation();
        createChat("Nuevo chat", project.id);
      });
      nested.appendChild(newChatButton);

      const chats = Object.values(project.chats || {}).sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
      chats.forEach(chat => nested.appendChild(createChatTreeItem(project, chat)));
      group.appendChild(nested);
    }

    els.projectList.appendChild(group);
  });
}

function createChatTreeItem(project, chat) {
  const div = document.createElement("div");
  div.className = "chat-item tree-chat-item" + (chat.id === project.currentChatId ? " active" : "");
  div.title = chat.title;

  const icon = document.createElement("span");
  icon.className = "chat-icon";
  icon.textContent = "•";

  const title = document.createElement("div");
  title.className = "chat-item-title";
  title.textContent = chat.title;

  const meta = document.createElement("span");
  meta.className = "item-count chat-message-count";
  const messageCount = Array.isArray(chat.messages) ? chat.messages.length : 0;
  meta.textContent = String(messageCount);
  meta.title = messageCount + (messageCount === 1 ? " mensaje" : " mensajes");

  const menuButton = document.createElement("button");
  menuButton.type = "button";
  menuButton.className = "item-menu-button";
  menuButton.textContent = "⋯";
  menuButton.title = "Opciones del chat";
  menuButton.addEventListener("click", event => {
    event.stopPropagation();
    state.currentProjectId = project.id;
    state.currentChatId = chat.id;
    project.currentChatId = chat.id;
    openChatMenu(event, chat.id);
  });

  div.appendChild(icon);
  div.appendChild(title);
  div.appendChild(meta);
  div.appendChild(menuButton);
  div.addEventListener("click", () => {
    state.currentProjectId = project.id;
    selectChat(chat.id);
  });
  return div;
}

function renderChats() {
  // La navegación de chats ahora está integrada dentro de cada proyecto en renderProjects().
}


function closeItemActionMenu() {
  const existing = document.querySelector(".item-action-menu");
  if (existing) existing.remove();
}

function openProjectMenu(event, projectId) {
  closeItemActionMenu();
  const menu = createItemActionMenu(event.currentTarget);

  const renameButton = document.createElement("button");
  renameButton.type = "button";
  renameButton.textContent = "Renombrar proyecto";
  renameButton.addEventListener("click", () => {
    closeItemActionMenu();
    renameProject(projectId);
  });

  const deleteButton = document.createElement("button");
  deleteButton.type = "button";
  deleteButton.className = "danger-action";
  deleteButton.textContent = projectId === "general" ? "No se puede eliminar" : "Eliminar proyecto";
  deleteButton.disabled = projectId === "general";
  deleteButton.addEventListener("click", () => {
    closeItemActionMenu();
    deleteProject(projectId);
  });

  menu.appendChild(renameButton);
  menu.appendChild(deleteButton);
  document.body.appendChild(menu);
  positionActionMenu(menu, event.currentTarget);
}

function openChatMenu(event, chatId) {
  closeItemActionMenu();
  const menu = createItemActionMenu(event.currentTarget);

  const renameButton = document.createElement("button");
  renameButton.type = "button";
  renameButton.textContent = "Renombrar chat";
  renameButton.addEventListener("click", () => {
    closeItemActionMenu();
    renameChat(chatId);
  });

  const moveButton = document.createElement("button");
  moveButton.type = "button";
  moveButton.textContent = "Mover a proyecto";
  moveButton.addEventListener("click", () => {
    closeItemActionMenu();
    moveChatToAnotherProject(chatId);
  });

  const deleteButton = document.createElement("button");
  deleteButton.type = "button";
  deleteButton.className = "danger-action";
  deleteButton.textContent = "Eliminar chat";
  deleteButton.addEventListener("click", () => {
    closeItemActionMenu();
    deleteChat(chatId);
  });

  menu.appendChild(renameButton);
  menu.appendChild(moveButton);
  menu.appendChild(deleteButton);
  document.body.appendChild(menu);
  positionActionMenu(menu, event.currentTarget);
}

function createItemActionMenu(button) {
  const menu = document.createElement("div");
  menu.className = "item-action-menu";
  menu.setAttribute("role", "menu");
  menu.dataset.anchor = button?.title || "Opciones";
  return menu;
}

function positionActionMenu(menu, anchor) {
  const rect = anchor.getBoundingClientRect();
  const menuWidth = 190;
  const left = Math.max(8, Math.min(window.innerWidth - menuWidth - 8, rect.right - menuWidth));
  const top = Math.min(window.innerHeight - 120, rect.bottom + 6);
  menu.style.left = left + "px";
  menu.style.top = top + "px";
}

function renameProject(projectId) {
  const project = state.projects?.[projectId];
  if (!project) return;

  const newName = prompt("Nuevo nombre del proyecto:", project.name || "");
  if (newName === null) return;

  const cleanName = newName.trim();
  if (!cleanName) {
    alert("El nombre del proyecto no puede estar vacío.");
    return;
  }

  project.name = cleanName;
  saveState();
  renderAll();
  setStatus("Proyecto renombrado");
}

function renameChat(chatId) {
  const project = getCurrentProject();
  const chat = project.chats?.[chatId];
  if (!chat) return;

  const newTitle = prompt("Nuevo nombre del chat:", chat.title || "");
  if (newTitle === null) return;

  const cleanTitle = newTitle.trim();
  if (!cleanTitle) {
    alert("El nombre del chat no puede estar vacío.");
    return;
  }

  chat.title = cleanTitle;
  chat.updatedAt = Date.now();
  saveState();
  renderAll();
  setStatus("Chat renombrado");
}


function deleteProject(projectId) {
  if (projectId === "general") {
    alert("El Proyecto General no se puede eliminar.");
    return;
  }

  const project = state.projects[projectId];
  if (!project) return;

  const chatCount = Object.keys(project.chats || {}).length;
  const confirmed = confirm(
    "¿Eliminar el proyecto \"" + project.name + "\" y sus " + chatCount + (chatCount === 1 ? " chat" : " chats") + "?\n\nEsta acción no se puede deshacer."
  );
  if (!confirmed) return;

  delete state.projects[projectId];

  if (!state.projects[state.currentProjectId]) {
    state.currentProjectId = state.projects.general ? "general" : Object.keys(state.projects)[0];
  }
  if (state.expandedProjectId === projectId) {
    state.expandedProjectId = state.currentProjectId || null;
  }

  const currentProject = getCurrentProject();
  state.currentChatId = currentProject.currentChatId;
  saveState();
  renderAll();
  setStatus("Proyecto eliminado");
}

function deleteChat(chatId) {
  const project = getCurrentProject();
  const chat = project.chats?.[chatId];
  if (!chat) return;

  const confirmed = confirm("¿Eliminar el chat \"" + chat.title + "\"?\n\nEsta acción no se puede deshacer.");
  if (!confirmed) return;

  delete project.chats[chatId];

  const remainingChatIds = Object.keys(project.chats || {});
  if (!remainingChatIds.length) {
    const replacementChat = createChatObject("Chat principal");
    project.chats[replacementChat.id] = replacementChat;
    project.currentChatId = replacementChat.id;
  } else if (project.currentChatId === chatId || !project.chats[project.currentChatId]) {
    project.currentChatId = remainingChatIds[0];
  }

  state.currentChatId = project.currentChatId;
  saveState();
  renderAll();
  setStatus("Chat eliminado");
}

function moveChatToAnotherProject(chatId) {
  const sourceProject = getCurrentProject();
  const chat = sourceProject.chats?.[chatId];
  if (!chat) return;

  const destinationProjects = Object.values(state.projects).filter(project => project.id !== sourceProject.id);
  if (!destinationProjects.length) {
    alert("Primero crea otro proyecto para poder mover este chat.");
    return;
  }

  const optionsText = destinationProjects
    .map((project, index) => (index + 1) + ". " + project.name)
    .join("\n");

  const selected = prompt(
    "Mover el chat \"" + chat.title + "\" a qué proyecto?\n\n" + optionsText + "\n\nEscribe el número del proyecto destino:"
  );

  if (selected === null) return;

  const selectedIndex = Number(selected.trim()) - 1;
  const targetProject = destinationProjects[selectedIndex];
  if (!targetProject) {
    alert("Selección inválida. No se movió el chat.");
    return;
  }

  const originalChatId = chat.id;
  let targetChatId = originalChatId;
  if (targetProject.chats[targetChatId]) {
    targetChatId = "chat_" + Date.now() + "_" + Math.random().toString(16).slice(2);
    chat.id = targetChatId;
  }

  delete sourceProject.chats[originalChatId];
  targetProject.chats[targetChatId] = chat;
  targetProject.currentChatId = targetChatId;
  chat.updatedAt = Date.now();

  const remainingChatIds = Object.keys(sourceProject.chats || {});
  if (!remainingChatIds.length) {
    const replacementChat = createChatObject("Chat principal");
    sourceProject.chats[replacementChat.id] = replacementChat;
    sourceProject.currentChatId = replacementChat.id;
  } else if (sourceProject.currentChatId === originalChatId || !sourceProject.chats[sourceProject.currentChatId]) {
    sourceProject.currentChatId = remainingChatIds[0];
  }

  state.currentProjectId = targetProject.id;
  state.currentChatId = targetChatId;
  state.expandedProjectId = targetProject.id;
  saveState();
  renderAll();
  setStatus("Chat movido a " + targetProject.name);
}

function renderConversation() {
  const project = getCurrentProject();
  const chat = getCurrentChat();
  const previousScrollTop = els.chat ? els.chat.scrollTop : 0;
  const previousScrollHeight = els.chat ? els.chat.scrollHeight : 0;
  const shouldStickToBottom = autoScrollEnabled || isChatNearBottom();

  els.currentProjectTitle.textContent = project.name;
  els.currentChatTitle.textContent = chat.title + " · Historial guardado en localStorage";
  els.chat.innerHTML = "";

  if (!chat.messages.length) {
    const welcome = document.createElement("div");
    welcome.className = "message assistant";
    welcome.textContent =
      "Hola. Este chat está dentro del proyecto \"" + project.name + "\". Puedes crear varios chats por proyecto para separar temas, clientes, cotizaciones o pruebas.";
    els.chat.appendChild(welcome);
  }

  chat.messages.forEach(msg => {
    const div = document.createElement("div");
    div.className = "message " + msg.role;
    if (msg.id) div.dataset.messageId = msg.id;

    const content = document.createElement("div");
    content.className = "message-content";

    if (msg.role === "assistant") {
      content.innerHTML = renderMarkdown(msg.content, msg.meta?.sources || []);
      content.addEventListener("click", event => {
        if (handleCodeBlockAction(event)) return;

        const citation = event.target.closest(".citation-chip");
        if (!citation) return;
        const sourceIndex = Number(citation.dataset.sourceIndex);
        const sources = msg.meta?.sources || [];
        if (sources.length) openSourcesDrawer(sources, sourceIndex);
      });
    } else {
      content.textContent = msg.content;
    }

    div.appendChild(content);

    if (msg.role === "user") {
      div.appendChild(createUserMessageActions(msg));
    }

    if (msg.role === "assistant" && msg.meta) {
      div.appendChild(createMetaBlock(msg.meta));
    }

    els.chat.appendChild(div);
  });

  if (shouldStickToBottom) {
    scrollChatToBottom(true);
  } else {
    const newScrollHeight = els.chat.scrollHeight;
    els.chat.scrollTop = Math.max(0, previousScrollTop + (newScrollHeight - previousScrollHeight));
    updateScrollToBottomButton();
  }
}

function createUserMessageActions(message) {
  const actions = document.createElement("div");
  actions.className = "user-message-actions";

  const copyButton = document.createElement("button");
  copyButton.type = "button";
  copyButton.className = "message-icon-btn";
  copyButton.title = "Copiar mensaje";
  copyButton.setAttribute("aria-label", "Copiar mensaje");
  copyButton.textContent = "⧉";
  copyButton.addEventListener("click", () => copyUserMessage(message, copyButton));

  const editButton = document.createElement("button");
  editButton.type = "button";
  editButton.className = "message-icon-btn";
  editButton.title = "Editar como nueva consulta";
  editButton.setAttribute("aria-label", "Editar como nueva consulta");
  editButton.textContent = "✎";
  editButton.addEventListener("click", () => editUserMessage(message));

  actions.appendChild(copyButton);
  actions.appendChild(editButton);
  return actions;
}

function copyUserMessage(message, button) {
  const text = message?.content || "";
  if (!text) return;

  navigator.clipboard.writeText(text).then(() => {
    const original = button.textContent;
    button.textContent = "✓";
    setTimeout(() => {
      button.textContent = original || "⧉";
    }, 1100);
  }).catch(() => {
    button.textContent = "!";
    setTimeout(() => {
      button.textContent = "⧉";
    }, 1100);
  });
}

function editUserMessage(message) {
  const text = message?.content || "";
  if (!text) return;

  els.messageInput.value = text;
  els.messageInput.focus();
  els.messageInput.setSelectionRange(els.messageInput.value.length, els.messageInput.value.length);
  setStatus("Mensaje copiado al cuadro de texto para editar y enviar nuevamente");
}

function createMetaBlock(meta) {
  const metaDiv = document.createElement("div");
  metaDiv.className = "message-meta";

  const usage = meta.usage || {};
  const webStatus = meta.webSearchUsed ? "Sí" : "No";
  const thinkingStatus = meta.deepThinking ? "Sí" : "No";

  const summary = document.createElement("div");
  summary.className = "meta-summary-line";
  summary.textContent =
    "Modelo: " + (meta.model || "No reportado") +
    " · Pensamiento profundo: " + thinkingStatus +
    " · Tokens entrada: " + valueOrNA(usage.prompt_tokens) +
    " · Tokens salida: " + valueOrNA(usage.completion_tokens) +
    " · Tokens total: " + valueOrNA(usage.total_tokens) +
    " · Búsqueda web: " + webStatus +
    (meta.webSearchUsed ? " · Páginas consultadas: " + valueOrNA(meta.resolvedWebResults || (meta.sources ? meta.sources.length : null)) + " · Modo: " + (meta.webSearchMode || "Manual") : "");
  metaDiv.appendChild(summary);

  if (meta.timings) {
    const timingLine = document.createElement("div");
    timingLine.className = "meta-timing-line";
    const timingParts = [];
    if (meta.timings.totalMs !== null && meta.timings.totalMs !== undefined) timingParts.push("Tiempo total: " + formatMs(meta.timings.totalMs));
    if (meta.timings.firstTokenMs !== null && meta.timings.firstTokenMs !== undefined) timingParts.push("Primer texto: " + formatMs(meta.timings.firstTokenMs));
    if (meta.timings.webSearchMs !== null && meta.timings.webSearchMs !== undefined) timingParts.push("Web: " + formatMs(meta.timings.webSearchMs));
    if (meta.timings.deepSeekMs !== null && meta.timings.deepSeekMs !== undefined) timingParts.push("DeepSeek: " + formatMs(meta.timings.deepSeekMs));
    if (meta.timings.documentsMs !== null && meta.timings.documentsMs !== undefined && meta.timings.documentsMs > 0) timingParts.push("Docs: " + formatMs(meta.timings.documentsMs));
    timingLine.textContent = timingParts.join(" · ");
    if (timingParts.length) metaDiv.appendChild(timingLine);
  }

  const chips = document.createElement("div");
  chips.className = "result-chips";

  if (meta.sources && meta.sources.length) {
    const sourceButton = document.createElement("button");
    sourceButton.type = "button";
    sourceButton.className = "web-result-chip";
    sourceButton.innerHTML = "🌐 <strong>" + meta.sources.length + "</strong> páginas web";
    sourceButton.title = "Ver resultados de búsqueda";
    sourceButton.addEventListener("click", () => openSourcesDrawer(meta.sources));
    chips.appendChild(sourceButton);
  }

  if (meta.documents && meta.documents.length) {
    const docButton = document.createElement("button");
    docButton.type = "button";
    docButton.className = "web-result-chip document-chip";
    docButton.innerHTML = "📄 <strong>" + meta.documents.length + "</strong> documento" + (meta.documents.length === 1 ? "" : "s");
    docButton.title = meta.documents.map(doc => doc.name).join("\n");
    chips.appendChild(docButton);
  }

  if (chips.children.length) metaDiv.appendChild(chips);

  return metaDiv;
}


function isCodeFenceLine(line) {
  return /^```\s*([\w.+-]*)\s*$/.test(String(line || "").trim());
}

function isCodeFenceCloseLine(line) {
  return /^```\s*$/.test(String(line || "").trim());
}


function renderMarkdown(text, sources = []) {
  const lines = String(text || "").replace(/\r\n/g, "\n").split("\n");
  const html = [];
  let index = 0;

  while (index < lines.length) {
    const line = lines[index];
    const trimmed = line.trim();

    if (!trimmed) {
      index += 1;
      continue;
    }

    const fencedCode = trimmed.match(/^```\s*([\w.+-]*)\s*$/);
    if (fencedCode) {
      const language = fencedCode[1] || "code";
      const codeLines = [];
      index += 1;
      while (index < lines.length && !isCodeFenceCloseLine(lines[index])) {
        codeLines.push(lines[index]);
        index += 1;
      }
      if (index < lines.length) index += 1;
      html.push(renderCodeBlock(codeLines.join("\n"), language));
      continue;
    }

    if (/^-{3,}$/.test(trimmed)) {
      html.push("<hr>");
      index += 1;
      continue;
    }

    const heading = trimmed.match(/^(#{1,4})\s+(.+)$/);
    if (heading) {
      const level = Math.min(heading[1].length + 1, 4);
      html.push("<h" + level + ">" + renderInlineMarkdown(heading[2], sources) + "</h" + level + ">");
      index += 1;
      continue;
    }

    if (isTableStart(lines, index)) {
      const tableLines = [];
      while (index < lines.length && lines[index].includes("|")) {
        tableLines.push(lines[index]);
        index += 1;
      }
      html.push(renderMarkdownTable(tableLines, sources));
      continue;
    }

    if (/^[-*•]\s+/.test(trimmed)) {
      const items = [];
      while (index < lines.length && /^[-*•]\s+/.test(lines[index].trim())) {
        items.push(lines[index].trim().replace(/^[-*•]\s+/, ""));
        index += 1;
      }
      html.push("<ul>" + items.map(item => "<li>" + renderInlineMarkdown(item, sources) + "</li>").join("") + "</ul>");
      continue;
    }

    if (/^\d+[.)]\s+/.test(trimmed)) {
      const items = [];
      while (index < lines.length && /^\d+[.)]\s+/.test(lines[index].trim())) {
        items.push(lines[index].trim().replace(/^\d+[.)]\s+/, ""));
        index += 1;
      }
      html.push("<ol>" + items.map(item => "<li>" + renderInlineMarkdown(item, sources) + "</li>").join("") + "</ol>");
      continue;
    }

    const paragraphLines = [];
    while (
      index < lines.length &&
      lines[index].trim() &&
      !/^-{3,}$/.test(lines[index].trim()) &&
      !/^(#{1,4})\s+/.test(lines[index].trim()) &&
      !isTableStart(lines, index) &&
      !/^[-*•]\s+/.test(lines[index].trim()) &&
      !/^\d+[.)]\s+/.test(lines[index].trim()) &&
      !isCodeFenceLine(lines[index])
    ) {
      paragraphLines.push(lines[index].trim());
      index += 1;
    }

    html.push("<p>" + paragraphLines.map(part => renderInlineMarkdown(part, sources)).join("<br>") + "</p>");
  }

  return html.join("\n");
}

function renderCodeBlock(code, language = "code") {
  const cleanLanguage = normalizeCodeLanguage(language);
  const highlighted = highlightCode(code, cleanLanguage);
  const canRun = isRunnableCodeBlock(code, cleanLanguage);

  return (
    '<div class="code-block">' +
    '<div class="code-block-header">' +
    '<span class="code-language-label">' + escapeHtml(cleanLanguage || "code") + '</span>' +
    '<div class="code-block-actions">' +
    '<button type="button" class="code-action-btn code-copy-btn" title="Copiar código">⧉ Copiar</button>' +
    '<button type="button" class="code-action-btn code-download-btn" title="Descargar código">⇩ Descargar</button>' +
    (canRun ? '<button type="button" class="code-action-btn code-run-btn" title="Ejecutar vista previa HTML/CSS/JS">▶ Ejecutar</button>' : '') +
    '</div>' +
    '</div>' +
    '<pre><code class="language-' + escapeHtml(cleanLanguage) + '" data-code-language="' + escapeHtml(cleanLanguage) + '">' + highlighted + '</code></pre>' +
    '</div>'
  );
}

function normalizeCodeLanguage(language) {
  const value = String(language || "code").trim().toLowerCase();
  if (!value) return "code";
  const aliases = {
    js: "javascript",
    ts: "typescript",
    py: "python",
    shell: "bash",
    sh: "bash",
    zsh: "bash",
    ps1: "powershell"
  };
  return aliases[value] || value;
}

function isRunnableCodeBlock(code, language) {
  const normalizedLanguage = normalizeCodeLanguage(language);
  const rawCode = String(code || "").trim().toLowerCase();

  if (["html", "javascript", "css"].includes(normalizedLanguage)) return true;
  if (rawCode.includes("<!doctype html") || rawCode.includes("<html")) return true;

  return false;
}

function getCodeBlockData(button) {
  const codeBlock = button.closest(".code-block");
  const codeElement = codeBlock?.querySelector("code");
  if (!codeElement) return null;

  const language = normalizeCodeLanguage(codeElement.dataset.codeLanguage || codeElement.className.replace(/^language-/, "") || "code");
  const code = codeElement.textContent || "";
  return { codeBlock, codeElement, language, code };
}

function handleCodeBlockAction(event) {
  const copyButton = event.target.closest(".code-copy-btn");
  if (copyButton) {
    copyCodeBlock(copyButton);
    return true;
  }

  const downloadButton = event.target.closest(".code-download-btn");
  if (downloadButton) {
    downloadCodeBlock(downloadButton);
    return true;
  }

  const runButton = event.target.closest(".code-run-btn");
  if (runButton) {
    runCodeBlock(runButton);
    return true;
  }

  return false;
}

function getFileExtensionForLanguage(language, code = "") {
  const normalizedLanguage = normalizeCodeLanguage(language);
  const rawCode = String(code || "").trim().toLowerCase();

  if (normalizedLanguage === "html" || rawCode.includes("<!doctype html") || rawCode.includes("<html")) return "html";
  if (normalizedLanguage === "css") return "css";
  if (normalizedLanguage === "javascript") return "js";
  if (normalizedLanguage === "typescript") return "ts";
  if (normalizedLanguage === "python") return "py";
  if (normalizedLanguage === "json") return "json";
  if (normalizedLanguage === "sql") return "sql";
  if (normalizedLanguage === "bash") return "sh";
  if (normalizedLanguage === "powershell") return "ps1";
  if (normalizedLanguage === "xml") return "xml";
  if (normalizedLanguage === "yaml") return "yml";
  if (normalizedLanguage === "java") return "java";
  if (normalizedLanguage === "csharp") return "cs";
  if (normalizedLanguage === "cpp") return "cpp";
  if (normalizedLanguage === "c") return "c";

  return "txt";
}

function createDownloadFileName(language, code = "") {
  const extension = getFileExtensionForLanguage(language, code);
  const timestamp = new Date().toISOString().slice(0, 19).replace(/[T:]/g, "-");
  return "codigo-ia-smelpro-" + timestamp + "." + extension;
}

function buildRunnableHtml(code, language) {
  const normalizedLanguage = normalizeCodeLanguage(language);
  const rawCode = String(code || "");
  const rawLower = rawCode.trim().toLowerCase();

  if (normalizedLanguage === "html" || rawLower.includes("<!doctype html") || rawLower.includes("<html")) {
    return rawCode;
  }

  if (normalizedLanguage === "css") {
    return `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>${rawCode}</style>
</head>
<body>
  <h1>Vista previa CSS</h1>
  <p>El CSS se aplicó a esta vista previa.</p>
  <button>Botón de prueba</button>
</body>
</html>`;
  }

  if (normalizedLanguage === "javascript") {
    const safeScript = rawCode.replace(/<\/script/gi, "<\\/script");
    return `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Vista previa JavaScript</title>
</head>
<body>
  <h1>Vista previa JavaScript</h1>
  <p>Abre la consola del navegador si el código usa console.log().</p>
  <script>${safeScript}</script>
</body>
</html>`;
  }

  return rawCode;
}

function highlightCode(code, language) {
  // Resaltado estable con Highlight.js.
  // Si la libreria no carga o el lenguaje no existe, usa fallback seguro.
  const rawCode = String(code || "");
  const normalizedLanguage = normalizeCodeLanguage(language);

  if (window.hljs) {
    try {
      if (normalizedLanguage && normalizedLanguage !== "code" && window.hljs.getLanguage(normalizedLanguage)) {
        return window.hljs.highlight(rawCode, {
          language: normalizedLanguage,
          ignoreIllegals: true
        }).value;
      }

      return window.hljs.highlightAuto(rawCode).value;
    } catch (error) {
      console.warn("No se pudo aplicar resaltado de sintaxis", error);
    }
  }

  return escapeHtml(rawCode);
}

function copyCodeBlock(button) {
  const data = getCodeBlockData(button);
  if (!data) return;

  navigator.clipboard.writeText(data.code).then(() => {
    const originalText = button.textContent;
    button.textContent = "✓ Copiado";
    setTimeout(() => {
      button.textContent = originalText || "⧉ Copiar";
    }, 1200);
  }).catch(() => {
    button.textContent = "Error";
    setTimeout(() => {
      button.textContent = "⧉ Copiar";
    }, 1200);
  });
}

function downloadCodeBlock(button) {
  const data = getCodeBlockData(button);
  if (!data) return;

  const fileName = createDownloadFileName(data.language, data.code);
  const blob = new Blob([data.code], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);

  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);

  const originalText = button.textContent;
  button.textContent = "✓ Descargado";
  setTimeout(() => {
    button.textContent = originalText || "⇩ Descargar";
  }, 1200);
}

function runCodeBlock(button) {
  const data = getCodeBlockData(button);
  if (!data) return;

  if (!isRunnableCodeBlock(data.code, data.language)) {
    alert("La vista previa solo está habilitada para HTML, CSS y JavaScript de navegador.");
    return;
  }

  openCodePreview(data.code, data.language);
}

function openCodePreview(code, language) {
  if (!els.codePreviewModal || !els.codePreviewFrame || !els.codePreviewOverlay) return;

  const html = buildRunnableHtml(code, language);
  const extension = getFileExtensionForLanguage(language, code).toUpperCase();

  if (els.codePreviewTitle) {
    els.codePreviewTitle.textContent = "Vista previa " + extension;
  }

  els.codePreviewOverlay.hidden = false;
  els.codePreviewModal.hidden = false;
  els.codePreviewModal.setAttribute("aria-hidden", "false");
  els.codePreviewModal.classList.add("open");
  els.codePreviewFrame.setAttribute("sandbox", "allow-scripts allow-forms allow-modals");
  els.codePreviewFrame.removeAttribute("src");
  els.codePreviewFrame.srcdoc = html;
}

function closeCodePreviewModal() {
  if (els.codePreviewOverlay) {
    els.codePreviewOverlay.hidden = true;
  }

  if (els.codePreviewModal) {
    els.codePreviewModal.hidden = true;
    els.codePreviewModal.setAttribute("aria-hidden", "true");
    els.codePreviewModal.classList.remove("open");
  }

  if (els.codePreviewFrame) {
    els.codePreviewFrame.removeAttribute("srcdoc");
    els.codePreviewFrame.src = "about:blank";
  }
}

function isTableStart(lines, index) {
  const current = lines[index] || "";
  const next = lines[index + 1] || "";
  return current.includes("|") && /^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$/.test(next);
}

function renderMarkdownTable(tableLines, sources) {
  if (tableLines.length < 2) return "";

  const rows = tableLines
    .filter((_line, index) => index !== 1)
    .map(line => splitTableRow(line));

  if (!rows.length) return "";

  const header = rows[0];
  const bodyRows = rows.slice(1);

  const headerHtml = header.map(cell => "<th>" + renderInlineMarkdown(cell, sources) + "</th>").join("");
  const bodyHtml = bodyRows.map(row => {
    return "<tr>" + row.map(cell => "<td>" + renderInlineMarkdown(cell, sources) + "</td>").join("") + "</tr>";
  }).join("");

  return '<div class="markdown-table-wrap"><table><thead><tr>' + headerHtml + '</tr></thead><tbody>' + bodyHtml + '</tbody></table></div>';
}

function splitTableRow(line) {
  return line
    .trim()
    .replace(/^\|/, "")
    .replace(/\|$/, "")
    .split("|")
    .map(cell => cell.trim());
}

function renderInlineMarkdown(text, sources = []) {
  let html = escapeHtml(text);

  html = html.replace(/`([^`]+)`/g, "<code>$1</code>");
  html = html.replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>");
  html = html.replace(/\*([^*]+)\*/g, "<em>$1</em>");

  html = html.replace(/\[(\d{1,2})\]/g, (_match, numberText) => {
    const sourceNumber = Number(numberText);
    const sourceIndex = sourceNumber - 1;
    const source = sources[sourceIndex];
    const title = source?.title ? escapeHtml(source.title) : "Fuente " + sourceNumber;
    const disabledClass = source ? "" : " disabled";
    return '<button type="button" class="citation-chip' + disabledClass + '" data-source-index="' + sourceIndex + '" title="' + title + '">' + sourceNumber + '</button>';
  });

  return html;
}

function escapeHtml(value) {
  return String(value || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function openSourcesDrawer(sources, selectedIndex = null) {
  if (!els.sourcesDrawer || !els.sourcesDrawerList) return;

  els.sourcesDrawerList.innerHTML = "";
  const safeSources = Array.isArray(sources) ? sources : [];

  if (els.sourcesDrawerSubtitle) {
    els.sourcesDrawerSubtitle.textContent = safeSources.length + (safeSources.length === 1 ? " fuente consultada" : " fuentes consultadas");
  }

  safeSources.forEach((source, index) => {
    const item = document.createElement("a");
    item.className = "drawer-source-item" + (index === selectedIndex ? " selected" : "");
    item.dataset.sourceIndex = String(index);
    item.href = source.url || "#";
    item.target = "_blank";
    item.rel = "noopener noreferrer";

    const number = document.createElement("div");
    number.className = "drawer-source-number";
    number.textContent = index + 1;

    const body = document.createElement("div");
    body.className = "drawer-source-body";

    const title = document.createElement("div");
    title.className = "drawer-source-title";
    title.textContent = source.title || source.url || "Fuente sin título";

    const domain = document.createElement("div");
    domain.className = "drawer-source-domain";
    domain.textContent = getDomainName(source.url || "");

    const snippet = document.createElement("div");
    snippet.className = "drawer-source-snippet";
    snippet.textContent = source.content || "Sin extracto disponible.";

    body.appendChild(title);
    body.appendChild(domain);
    body.appendChild(snippet);
    item.appendChild(number);
    item.appendChild(body);
    els.sourcesDrawerList.appendChild(item);
  });

  if (els.drawerOverlay) els.drawerOverlay.hidden = false;
  els.sourcesDrawer.classList.add("open");
  els.sourcesDrawer.setAttribute("aria-hidden", "false");

  if (selectedIndex !== null && selectedIndex !== undefined) {
    window.setTimeout(() => {
      const selected = els.sourcesDrawerList.querySelector('[data-source-index="' + selectedIndex + '"]');
      if (selected) selected.scrollIntoView({ block: "center", behavior: "smooth" });
    }, 80);
  }
}

function closeSourcesDrawer() {
  if (els.drawerOverlay) els.drawerOverlay.hidden = true;
  if (els.sourcesDrawer) {
    els.sourcesDrawer.classList.remove("open");
    els.sourcesDrawer.setAttribute("aria-hidden", "true");
  }
}

function getDomainName(url) {
  try {
    const parsed = new URL(url);
    return parsed.hostname.replace(/^www\./, "");
  } catch (_error) {
    return url || "";
  }
}

function valueOrNA(value) {
  return value === undefined || value === null ? "No reportado" : value;
}

function formatMs(value) {
  if (value === undefined || value === null) return "No reportado";
  const number = Number(value);
  if (!Number.isFinite(number)) return "No reportado";
  if (number >= 1000) return (number / 1000).toFixed(number >= 10000 ? 1 : 2).replace(/\.00$/, "") + " s";
  return Math.round(number) + " ms";
}

function createMessageId() {
  return "msg_" + Date.now() + "_" + Math.random().toString(16).slice(2);
}

function clearCurrentChat() {
  const chat = getCurrentChat();
  if (!confirm("¿Limpiar el chat actual?")) return;

  chat.messages = [];
  chat.updatedAt = Date.now();
  saveState();
  renderAll();
  setStatus("Chat limpiado");
}

function setStatus(text) {
  els.status.textContent = text;
}

function getConversationForApi(chat) {
  return chat.messages
    .filter(message => message.role === "user" || message.role === "assistant")
    .map(message => ({
      role: message.role,
      content: message.content
    }));
}

function updateChatTitleFromFirstMessage(chat, text) {
  const genericTitles = ["Nuevo chat", "Chat principal", "Chat sin título"];
  if (!genericTitles.includes(chat.title)) return;

  const clean = text.replace(/\s+/g, " ").trim();
  if (!clean) return;

  chat.title = clean.length > 42 ? clean.slice(0, 42) + "..." : clean;
}

function bindComposerDragAndDrop() {
  const dropZone = els.composerCard || els.messageInput;
  if (!dropZone) return;

  let dragDepth = 0;

  ["dragenter", "dragover"].forEach(eventName => {
    dropZone.addEventListener(eventName, event => {
      event.preventDefault();
      event.stopPropagation();
      dragDepth += eventName === "dragenter" ? 1 : 0;
      dropZone.classList.add("drag-over");
    });
  });

  ["dragleave", "dragend"].forEach(eventName => {
    dropZone.addEventListener(eventName, event => {
      event.preventDefault();
      event.stopPropagation();
      dragDepth = Math.max(0, dragDepth - 1);
      if (dragDepth === 0 || eventName === "dragend") dropZone.classList.remove("drag-over");
    });
  });

  dropZone.addEventListener("drop", event => {
    event.preventDefault();
    event.stopPropagation();
    dragDepth = 0;
    dropZone.classList.remove("drag-over");
    addDocumentFiles(Array.from(event.dataTransfer?.files || []));
  });
}

function addDocumentFiles(incomingFiles) {
  if (!incomingFiles.length) return;

  const allowedExtensions = ["txt", "md", "pdf", "docx"];
  const accepted = [];

  incomingFiles.forEach(file => {
    const extension = file.name.split(".").pop().toLowerCase();
    if (!allowedExtensions.includes(extension)) {
      alert("Archivo no soportado: " + file.name + "\nUsa TXT, MD, PDF o DOCX.");
      return;
    }
    accepted.push(file);
  });

  if (!accepted.length) return;
  selectedDocumentFiles = [...selectedDocumentFiles, ...accepted].slice(0, 5);
  if (els.documentInput) els.documentInput.value = "";
  renderAttachedFiles();
  setStatus(accepted.length + (accepted.length === 1 ? " documento adjunto" : " documentos adjuntos"));
}

function handleDocumentSelection(event) {
  addDocumentFiles(Array.from(event.target.files || []));
}

function renderAttachedFiles() {
  if (!els.attachedFiles) return;

  els.attachedFiles.innerHTML = "";

  if (!selectedDocumentFiles.length) {
    els.attachedFiles.style.display = "none";
    return;
  }

  els.attachedFiles.style.display = "flex";

  selectedDocumentFiles.forEach((file, index) => {
    const chip = document.createElement("div");
    chip.className = "file-chip";

    const name = document.createElement("span");
    name.textContent = "📄 " + file.name;

    const remove = document.createElement("button");
    remove.type = "button";
    remove.textContent = "×";
    remove.title = "Quitar archivo";
    remove.addEventListener("click", () => {
      selectedDocumentFiles = selectedDocumentFiles.filter((_file, fileIndex) => fileIndex !== index);
      renderAttachedFiles();
    });

    chip.appendChild(name);
    chip.appendChild(remove);
    els.attachedFiles.appendChild(chip);
  });
}

function clearAttachedFiles() {
  selectedDocumentFiles = [];
  if (els.documentInput) els.documentInput.value = "";
  renderAttachedFiles();
}

function showProcessingIndicator() {
  if (!els.chat) return;
  removeProcessingIndicator();

  const loading = document.createElement("div");
  loading.id = "processingIndicator";
  loading.className = "message assistant loading-message";
  loading.setAttribute("aria-label", "Procesando respuesta");
  loading.innerHTML = '<div class="thinking-dots"><span></span><span></span><span></span></div>';
  els.chat.appendChild(loading);
  scrollChatToBottom();
}

function removeProcessingIndicator() {
  const existing = document.getElementById("processingIndicator");
  if (existing) existing.remove();
}

function buildRequestBody(chat) {
  const payload = {
    model: state.settings.model,
    deepThinking: state.settings.deepThinking,
    systemPrompt: state.settings.systemPrompt,
    messages: getConversationForApi(chat),
    useWebSearch: state.settings.useWebSearch,
    maxResults: state.settings.maxResults
  };

  if (!selectedDocumentFiles.length) {
    return {
      body: JSON.stringify(payload),
      headers: { "Content-Type": "application/json" }
    };
  }

  const formData = new FormData();
  Object.entries(payload).forEach(([key, value]) => {
    formData.append(key, typeof value === "string" ? value : JSON.stringify(value));
  });

  selectedDocumentFiles.forEach(file => {
    formData.append("documents", file, file.name);
  });

  return { body: formData, headers: {} };
}

function updateStreamingMessageDom(message, sources = []) {
  if (!message?.id) return;
  const node = els.chat.querySelector('[data-message-id="' + message.id + '"] .message-content');
  if (!node) return;

  node.innerHTML = renderMarkdown(message.content || "", sources || []);

  node.onclick = event => {
        if (handleCodeBlockAction(event)) return;

        const citation = event.target.closest(".citation-chip");
    if (!citation) return;
    const sourceIndex = Number(citation.dataset.sourceIndex);
    const safeSources = sources || [];
    if (safeSources.length) openSourcesDrawer(safeSources, sourceIndex);
  };

  scrollChatToBottom();
}

function createAssistantMessageDom(message, sources = []) {
  if (!message?.id) return;
  const div = document.createElement("div");
  div.className = "message assistant";
  div.dataset.messageId = message.id;

  const content = document.createElement("div");
  content.className = "message-content";
  div.appendChild(content);
  els.chat.appendChild(div);
  updateStreamingMessageDom(message, sources);
}

async function readSseStream(response, handlers = {}) {
  if (!response.body) {
    throw new Error("La aplicación no devolvió un flujo de datos.");
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder("utf-8");
  let buffer = "";

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const events = buffer.split("\n\n");
    buffer = events.pop() || "";

    for (const rawEvent of events) {
      const parsed = parseSseEvent(rawEvent);
      if (!parsed) continue;

      if (parsed.event === "meta" && handlers.onMeta) handlers.onMeta(parsed.data);
      if (parsed.event === "delta" && handlers.onDelta) handlers.onDelta(parsed.data);
      if (parsed.event === "done" && handlers.onDone) handlers.onDone(parsed.data);
      if (parsed.event === "error") {
        throw new Error(parsed.data?.error || "Error en el flujo de respuesta.");
      }
    }
  }
}

function parseSseEvent(rawEvent) {
  const lines = String(rawEvent || "").split("\n");
  let event = "message";
  const dataLines = [];

  lines.forEach(line => {
    if (line.startsWith("event:")) event = line.slice(6).trim();
    if (line.startsWith("data:")) dataLines.push(line.slice(5).trim());
  });

  if (!dataLines.length) return null;

  try {
    return {
      event,
      data: JSON.parse(dataLines.join("\n"))
    };
  } catch (_error) {
    return null;
  }
}


async function sendMessage() {
  if (isGenerating) return;
  saveSettings();

  const text = els.messageInput.value.trim();
  if (!text) return;

  const project = getCurrentProject();
  const chat = getCurrentChat();

  updateChatTitleFromFirstMessage(chat, text);

  chat.messages.push({
    id: createMessageId(),
    role: "user",
    content: text
  });

  chat.updatedAt = Date.now();
  els.messageInput.value = "";
  saveState();
  autoScrollEnabled = true;
  renderAll();
  scrollChatToBottom(true);
  showProcessingIndicator();

  const statusParts = [];
  if (state.settings.useWebSearch) statusParts.push("buscando en internet");
  if (state.settings.deepThinking) statusParts.push("razonando con pensamiento profundo");
  if (selectedDocumentFiles.length) statusParts.push("leyendo documentos");

  setStatus(statusParts.length ? "Procesando: " + statusParts.join(", ") + "..." : "Consultando DeepSeek...");
  currentAbortController = new AbortController();
  setSendButtonMode(true);

  const request = buildRequestBody(chat);
  let assistantMessage = null;
  let streamedMeta = {
    model: state.settings.model,
    usage: {},
    sources: [],
    documents: [],
    webSearchUsed: state.settings.useWebSearch,
    webSearchMode: state.settings.maxResults === "auto" ? "Automático" : "Manual",
    resolvedWebResults: null,
    deepThinking: state.settings.deepThinking,
    timings: {}
  };

  try {
    const response = await fetch("/api/chat-stream", {
      method: "POST",
      headers: request.headers,
      body: request.body,
      signal: currentAbortController.signal
    });

    if (!response.ok) {
      let errorMessage = "Error desconocido";
      try {
        const errorData = await response.json();
        errorMessage = errorData.error || errorMessage;
      } catch (_error) {
        errorMessage = await response.text();
      }
      throw new Error(errorMessage);
    }

    await readSseStream(response, {
      onMeta: data => {
        streamedMeta = {
          ...streamedMeta,
          ...data,
          usage: data.usage || streamedMeta.usage || {}
        };
      },
      onDelta: data => {
        const chunk = data?.text || "";
        if (!chunk) return;

        if (!assistantMessage) {
          removeProcessingIndicator();
          assistantMessage = {
            id: createMessageId(),
            role: "assistant",
            content: "",
            meta: streamedMeta
          };
          chat.messages.push(assistantMessage);
          createAssistantMessageDom(assistantMessage, streamedMeta.sources || []);
        }

        assistantMessage.content += chunk;
        updateStreamingMessageDom(assistantMessage, streamedMeta.sources || []);
      },
      onDone: data => {
        streamedMeta = {
          ...streamedMeta,
          ...data,
          usage: data.usage || streamedMeta.usage || {}
        };

        if (!assistantMessage) {
          removeProcessingIndicator();
          assistantMessage = {
            id: createMessageId(),
            role: "assistant",
            content: "No se recibió respuesta del modelo.",
            meta: streamedMeta
          };
          chat.messages.push(assistantMessage);
        }

        assistantMessage.meta = streamedMeta;
      }
    });

    if (!assistantMessage) {
      assistantMessage = {
        id: createMessageId(),
        role: "assistant",
        content: "No se recibió respuesta del modelo.",
        meta: streamedMeta
      };
      chat.messages.push(assistantMessage);
    }

    chat.updatedAt = Date.now();
    project.currentChatId = chat.id;
    state.currentChatId = chat.id;

    clearAttachedFiles();
    saveState();
    renderAll();
    setStatus("Listo");
  } catch (error) {
    removeProcessingIndicator();

    if (error.name === "AbortError") {
      if (assistantMessage) {
        assistantMessage.content = (assistantMessage.content || "").trimEnd() + "\n\n_Respuesta detenida por el usuario._";
        assistantMessage.meta = streamedMeta;
        chat.updatedAt = Date.now();
        saveState();
        renderAll();
      }
      setStatus("Respuesta detenida");
    } else {
      console.error(error);
      chat.messages.push({
        id: createMessageId(),
        role: "assistant",
        content: "Error al consultar la aplicación.\n\nDetalle: " + error.message,
        meta: {
          model: "No disponible",
          usage: {},
          sources: [],
          documents: [],
          webSearchUsed: state.settings.useWebSearch,
          webSearchMode: state.settings.maxResults === "auto" ? "Automático" : "Manual",
          resolvedWebResults: null,
          deepThinking: state.settings.deepThinking,
          timings: {}
        }
      });

      chat.updatedAt = Date.now();
      saveState();
      renderAll();
      setStatus("Error");
    }
  } finally {
    removeProcessingIndicator();
    currentAbortController = null;
    setSendButtonMode(false);
    els.messageInput.focus();
  }
}

